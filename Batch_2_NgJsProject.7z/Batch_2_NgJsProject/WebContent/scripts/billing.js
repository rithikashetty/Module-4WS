var billModule = angular.module("billModule",[])

billModule.controller("billContoller",
		function($scope){
			$scope.billItem = {
					'qty' : 1,
					'cost' : 1,
					'discount' : 0
					
			};
			
			$scope.calcBill = function(){
				return $scope.billItem.qty * $scope.billItem.cost;
				
			};
			
			$scope.calcDiscount = function(){
				return ($scope.billItem.discount==0) ? 0:$scope.calcBill() / $scope.billItem.discount;
			};
			
			$scope.calcNetBill = function(){
				return $scope.calcBill() - $scope.calcDiscount();
			}
        }

);